package server;

import java.sql.*;
import java.io.*;
import java.net.*;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author iljak
 */

public class Server {

    static public class MySQL {
        Connection connection;
        private String url = "jdbc:mysql://localhost:3306/hotel";
        private String user;
        private String password;
        Socket socket;
        BufferedReader in;
        PrintWriter out;
        ObjectInputStream objectIn;
        ObjectOutputStream objectOut;
        
        public boolean dbConnection(Socket socket, BufferedReader in, PrintWriter out, ObjectInputStream objectIn, ObjectOutputStream objectOut, String user, String password) throws IOException {
            this.socket = socket;
            this.user = user;
            this.password = password;
            this.in = in;
            this.out = out;
            this.objectIn = objectIn;
            this.objectOut = objectOut;
            try {
                connection = DriverManager.getConnection(url, user, password);
                System.out.println(user + " is connected to the database " + url);
                return true;
            } catch(SQLException ex) {
                out.println(ex.getMessage());
                System.out.println(ex.getMessage());
                return false;
            }
        }
        
        public void dbConnectionClose() {
            try {
                connection.close();
                System.out.println(user + " disconnected");
            } catch(SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }

        public void selectAllPost() throws IOException, InterruptedException {
            try {
                LinkedList<String> answer = new LinkedList<>();
                Statement statement = connection.createStatement();
                ResultSet result = statement.executeQuery("SELECT * FROM Postoyalec;");
                System.out.println(user + ": SELECT * FROM Postoyalec");
                while(result.next()){
                    answer.add(result.getString("Id_Postoyalca"));
                    answer.add(result.getString("Surname"));
                    answer.add(result.getString("Name"));
                    answer.add(result.getString("Patronymic"));
                    answer.add(result.getString("Passport"));
                    answer.add(result.getString("Address"));
                    answer.add(result.getString("Comment"));
                    answer.add(result.getString("Category"));
                    answer.add(result.getString("Discount"));
                }
                result.close();
                statement.close();
                objectOut.reset();
                objectOut.writeObject(answer);  
                objectOut.reset();
            } catch (SQLException ex){
                System.out.println(ex.getMessage());
            }
        }

        public void searchPost() throws IOException, InterruptedException{
            try {
                LinkedList<String> answer = new LinkedList<>(); 
                String post = in.readLine();
                Statement statement = connection.createStatement();
                String sql;
                if (post.equals("5") || post.equals("10") || post.equals("15")) {
                    sql = "SELECT * FROM Postoyalec WHERE Discount = '" + Integer.valueOf(post) + "';";
                }
                else {
                    sql = "SELECT * FROM Postoyalec WHERE Surname= '" + post + "' OR Name = '" + post + "' OR Patronymic = '" + post + "' OR Passport = '" + post + "' OR Address = '" + post + "';";
                }
                ResultSet result = statement.executeQuery(sql);
                System.out.println(user + ": SELECT * FROM Postoyalec WHERE " + post);
                while(result.next()){
                    answer.add(result.getString("Surname"));
                    answer.add(result.getString("Name"));
                    answer.add(result.getString("Patronymic"));
                    answer.add(result.getString("Passport"));
                    answer.add(result.getString("Address"));
                    answer.add(result.getString("Discount"));
                }
                result.close();
                statement.close();
                objectOut.reset();
                objectOut.writeObject(answer);
                objectOut.reset();
            } catch (SQLException ex) {
                Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        public void insertPost() throws IOException, ClassNotFoundException, InterruptedException {
            try {
                LinkedList<String> answer = (LinkedList<String>) objectIn.readObject();
                Statement statement = connection.createStatement();
                System.out.println(user + ": INSERT INTO Postoyalec");
                String sql = "INSERT INTO Postoyalec(Surname, Name, Patronymic, "
                    + "Passport, Address, Discount) VALUES ('"+answer.get(0)+"'"
                    + ",'"+answer.get(1)+"','"+answer.get(2)+"','"+answer.get(3)+"','"
                    + ""+answer.get(4)+"','"+ answer.get(5)+"');";
                statement.executeUpdate(sql);
                statement.close();
            } catch (SQLException ex) {
                Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        public void delPost() throws IOException, SQLException, InterruptedException{
            String answer = in.readLine();
            Statement statement = connection.createStatement();
            System.out.println(user + ": DELETE FROM Postoyalec");
            String sql = "DELETE FROM Postoyalec WHERE Id_Postoyalca= " + answer + " ;";
            statement.executeUpdate(sql);
            statement.close();
        }
            
        public void updPost() throws SQLException, IOException, ClassNotFoundException, InterruptedException   {
            LinkedList<String> answer = (LinkedList<String>) objectIn.readObject();
            Statement statement = connection.createStatement();
            System.out.println(user + ": UPDATE Postoyalec");
            String sql = "UPDATE Postoyalec SET Surname='" + answer.get(0) + "',Name='" + answer.get(1) + 
                "',Patronymic='" + answer.get(2) +"',Passport='" + answer.get(3) + "',Address='" + answer.get(4) + 
                "',Discount='" +answer.get(5) + "' WHERE Id_Postoyalca=" + answer.get(6) +";";
            statement.executeUpdate(sql);
            statement.close();
        }
        
        public void selectCheckIn() throws IOException{
            try {
                LinkedList<String> answer = new LinkedList<>();
                Statement statement = connection.createStatement();
                ResultSet result = statement.executeQuery("SELECT * FROM Postoyalec INNER JOIN Check_in ON Postoyalec.Id_Postoyalca = Check_in.Id_PostoyalcaC;");
                System.out.println(user + ": SELECT * FROM Check_in");
                while(result.next()){
                    answer.add(result.getString("Id_Postoyalca"));
                    answer.add(result.getString("Passport"));
                    answer.add(result.getString("Number_apartC"));
                    answer.add(result.getString("Date Check_in"));
                    answer.add(result.getString("Date Check_out"));
                }
                result.close();
                statement.close();
                objectOut.reset();
                objectOut.writeObject(answer);  
                objectOut.reset();
            } catch (SQLException ex){
                System.out.println(ex.getMessage());
            }    
        }
        
        public void insertCheckIn() throws IOException, ClassNotFoundException{
            try {
                LinkedList<String> answer = (LinkedList<String>) objectIn.readObject();
                Statement statement = connection.createStatement();
                System.out.println(user + ": INSERT INTO Check_in");
                String sql = "INSERT INTO Check_in(ID_PostoyalcaC, Number_apartC, `Date Check_in`, `Date Check_out`) VALUES ("+answer.get(0)+","+answer.get(3)+",'"+answer.get(1)+"','"+answer.get(2)+"');";
                statement.executeUpdate(sql);
                statement.close();
            } catch (SQLException ex) {
                Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        public void updCheckIn() throws SQLException, IOException, ClassNotFoundException   {
            LinkedList<String> answer = (LinkedList<String>) objectIn.readObject();
            Statement statement = connection.createStatement();
            System.out.println(user + ": UPDATE Check_in");
            String sql = "DELETE FROM Check_in WHERE Id_PostoyalcaC = " + answer.get(5) + " AND `Date Check_in` = '" + answer.get(0) +  "' AND `Date Check_out` = '" + answer.get(1) + "';";
            statement.executeUpdate(sql);
            sql = "INSERT INTO Check_in(ID_PostoyalcaC, Number_apartC, `Date Check_in`, `Date Check_out`) VALUES ("+answer.get(5)+","+answer.get(4)+",'"+answer.get(2)+"','"+answer.get(3)+"');";
            statement.executeUpdate(sql);
            statement.close();
        }
        
        public void delCheckIn() throws IOException, SQLException{
            String answer = in.readLine();
            Statement statement = connection.createStatement();
            System.out.println(user + ": DELETE FROM Check_in");
            String sql = "DELETE FROM Check_in WHERE Id_PostoyalcaC= " + answer + " ;";
            statement.executeUpdate(sql);
            statement.close();
        }
        
        public void searchCheckIn() throws IOException{
             try {
                LinkedList<String> answer = new LinkedList<>(); 
                String post = in.readLine();
                System.out.println(user + ": SELECT * FROM Check_in WHERE " + post);
                Statement statement = connection.createStatement();
                String sql;
                if (post.matches("\\d\\d\\d\\d-\\d\\d-\\d\\d")) {
                    sql = "SELECT * FROM Postoyalec INNER JOIN Check_in ON Postoyalec.ID_Postoyalca  = Check_in.ID_PostoyalcaC WHERE Check_in.`Date Check_in` = '" + post + "' OR Check_in.`Date Check_Out` = '" + post + "';";
                }
                else {
                    sql = "SELECT * FROM Postoyalec INNER JOIN Check_in ON Postoyalec.ID_Postoyalca  = Check_in.ID_PostoyalcaC WHERE Postoyalec.Passport = " + post + " OR Check_in.Number_apartC = '" + post + "' ;";
                }
                ResultSet result = statement.executeQuery(sql);
                while(result.next()){
                    answer.add(result.getString("Passport"));
                    answer.add(result.getString("Date Check_in"));
                    answer.add(result.getString("Date Check_Out"));
                    answer.add(result.getString("Number_apartC"));
                }
                result.close();
                statement.close();
                objectOut.reset();
                objectOut.writeObject(answer);
                objectOut.reset();
            } catch (SQLException ex) {
                Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        public void selectReserv() throws IOException{
            try {
                LinkedList<String> answer = new LinkedList<>();
                Statement statement = connection.createStatement();
                ResultSet result = statement.executeQuery("SELECT * FROM Postoyalec INNER JOIN Reservation ON Postoyalec.Id_Postoyalca = Reservation.Id_PostoyalcaR;");
                System.out.println(user + ": SELECT * FROM Reservation");
                while(result.next()){
                    answer.add(result.getString("Id_Postoyalca"));
                    answer.add(result.getString("Passport"));
                    answer.add(result.getString("Number_apartR"));
                    answer.add(result.getString("Booking start date"));
                    answer.add(result.getString("Booking finish date"));
                }
                result.close();
                statement.close();
                objectOut.reset();
                objectOut.writeObject(answer);  
                objectOut.reset();
            } catch (SQLException ex){
                System.out.println(ex.getMessage());
            }    
        }
        
        public void insertReserv() throws IOException, ClassNotFoundException{
            try {
                LinkedList<String> answer = (LinkedList<String>) objectIn.readObject();
                Statement statement = connection.createStatement();
                System.out.println(user + ": INSERT INTO Reservation");
                String sql = "INSERT INTO Reservation(ID_PostoyalcaR, Number_apartR, `Booking start date`, `Booking finish date`) VALUES ("+answer.get(0)+","+answer.get(3)+",'"+answer.get(1)+"','"+answer.get(2)+"');";
                statement.executeUpdate(sql);
                statement.close();
            } catch (SQLException ex) {
                Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        public void delReserv() throws IOException, SQLException{
            String answer = in.readLine();
            Statement statement = connection.createStatement();
            System.out.println(user + ": DELETE FROM Reservation");
            String sql = "DELETE FROM Reservation WHERE Id_PostoyalcaR= " + answer + " ;";
            statement.executeUpdate(sql);
            statement.close();
        }

        public void updReserv() throws SQLException, IOException, ClassNotFoundException   {
           LinkedList<String> answer = (LinkedList<String>) objectIn.readObject();
           Statement statement = connection.createStatement();
           System.out.println(user + ": UPDATE Reserv");
           String sql = "DELETE FROM Reservation WHERE Id_PostoyalcaR = " + answer.get(5) + " AND `Booking start date` = '" + answer.get(0) +  "' AND `Booking finish date` = '" + answer.get(1) + "';";
           statement.executeUpdate(sql);
           sql = "INSERT INTO Reservation(ID_PostoyalcaR, Number_apartR, `Booking start date`, `Booking finish date`) VALUES ("+answer.get(5)+","+answer.get(4)+",'"+answer.get(2)+"','"+answer.get(3)+"');";
           statement.executeUpdate(sql);
           statement.close();
        }

        public void searchReserv() throws IOException{
             try {
                LinkedList<String> answer = new LinkedList<>(); 
                String post = in.readLine();
                System.out.println(user + ": SELECT * FROM Reservation WHERE " + post);
                Statement statement = connection.createStatement();
                String sql;
                if (post.matches("\\d\\d\\d\\d-\\d\\d-\\d\\d")) {
                    sql = "SELECT * FROM Postoyalec INNER JOIN Reservation ON Postoyalec.ID_Postoyalca  = Reservation.ID_PostoyalcaR WHERE Reservation.`Booking start date` = '" + post + "' OR Reservation.`Booking finish date` = '" + post + "';";
                }
                else {
                    sql = "SELECT * FROM Postoyalec INNER JOIN Reservation ON Postoyalec.ID_Postoyalca  = Reservation.ID_PostoyalcaR WHERE Postoyalec.Passport = " + post + " OR Reservation.Number_apartR = '" + post + "' ;";
                }
                ResultSet result = statement.executeQuery(sql);
                while(result.next()){
                    answer.add(result.getString("Passport"));
                    answer.add(result.getString("Booking start date"));
                    answer.add(result.getString("Booking finish date"));
                    answer.add(result.getString("Number_apartR"));
                }
                result.close();
                statement.close();
                objectOut.reset();
                objectOut.writeObject(answer);
                objectOut.reset();
            } catch (SQLException ex) {
                Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        public void selectApart() throws IOException{
            try {
                LinkedList<String> answer = new LinkedList<>();
                Statement statement = connection.createStatement();
                ResultSet result = statement.executeQuery("SELECT * FROM Apart;");
                System.out.println(user + ": SELECT * FROM Apart");
                while(result.next()){
                    answer.add(result.getString("Number_apart"));
                    answer.add(result.getString("Capacity"));
                    answer.add(result.getString("Comfort"));
                    answer.add(result.getString("Price"));
                    answer.add(result.getString("Free"));
                }
                result.close();
                statement.close();
                objectOut.reset();
                objectOut.writeObject(answer);  
                objectOut.reset();
            } catch (SQLException ex){
                System.out.println(ex.getMessage());
            }    
        }

        public void insertApart() throws ClassNotFoundException, IOException {
            try {
                LinkedList<String> answer = (LinkedList<String>) objectIn.readObject();
                Statement statement = connection.createStatement();
                System.out.println(user + ": INSERT INTO Apart");
                String sql = "SET foreign_key_checks = 0;";
                statement.executeUpdate(sql);
                sql = "INSERT INTO Apart(Number_apart, Capacity, Comfort, Price, Free) VALUES ("+answer.get(0)+","+answer.get(1)+",'"+answer.get(2)+"',"+answer.get(3)+",'"+answer.get(4)+"');";
                statement.executeUpdate(sql);
                sql = "SET foreign_key_checks = 1;";
                statement.executeUpdate(sql);
                statement.close();
            } catch (SQLException ex) {
                Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
                System.out.println(ex.getMessage());
            }
        }
        
        public void updApart() throws SQLException, IOException, ClassNotFoundException{
            LinkedList<String> answer = (LinkedList<String>) objectIn.readObject();
            Statement statement = connection.createStatement();
            System.out.println(user + ": UPDATE Postoyalec");
            String sql = "UPDATE Apart SET Capacity = " + answer.get(0) + 
                ", Comfort = '" + answer.get(1) +"', Price= " + answer.get(2) + ", Free = '" + answer.get(3) + 
                "' WHERE Number_apart = " + answer.get(4) +";";
            statement.executeUpdate(sql);
            statement.close();
        }

        public void searchApart() throws IOException{
            try {
                LinkedList<String> answer = new LinkedList<>(); 
                String post = in.readLine();
                System.out.println(user + ": SELECT * FROM Reservation WHERE " + post);
                Statement statement = connection.createStatement();
                String sql;
                if ("Да".equals(post)) sql = "SELECT * FROM Apart WHERE Free = '1';";
                else if ("Нет".equals(post)) sql = "SELECT * FROM Apart WHERE Free = '0';";
                else if ("lux".equals(post) || "polulux".equals(post) || "econom".equals(post)) sql = "SELECT * FROM Apart WHERE Comfort = '" + post + "';";
                else sql = "SELECT * FROM Apart WHERE Number_apart = " + post + " OR Capacity = " + post + " OR Price = " + post + ";";
                ResultSet result = statement.executeQuery(sql);
                while(result.next()){
                    answer.add(result.getString("Number_apart"));
                    answer.add(result.getString("Capacity"));
                    answer.add(result.getString("Comfort"));
                    answer.add(result.getString("Price"));
                    answer.add(result.getString("Free"));
                }
                result.close();
                statement.close();
                objectOut.reset();
                objectOut.writeObject(answer);
                objectOut.reset();
            } catch (SQLException ex) {
                Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        public void delApart() throws IOException, SQLException{
            String answer = in.readLine();
            Statement statement = connection.createStatement();
            System.out.println(user + ": DELETE FROM Reservation");
            String sql = "DELETE FROM Apart WHERE Number_apart = " + answer + " ;";
            statement.executeUpdate(sql);
            statement.close();
        }

    }
    
    static public class dbServer extends Thread{
        private Socket socket;
        private BufferedReader in;
        private PrintWriter out;
        private ObjectOutputStream objectOut;
        private ObjectInputStream objectIn;
        
        public dbServer(Socket s) throws IOException{
            socket = s;
            out = new PrintWriter(new BufferedWriter(
                new OutputStreamWriter(socket.getOutputStream())), true);
            in = new BufferedReader(new 
            InputStreamReader(socket.getInputStream()));
            objectOut = new ObjectOutputStream(socket.getOutputStream());
            objectIn = new ObjectInputStream(socket.getInputStream());
        }
        
        @Override
        public void run(){
            try {
                MySQL connect = new MySQL();
                String user = in.readLine();
                String password = in.readLine();
                if(connect.dbConnection(socket, in, out, objectIn, objectOut, user, password) == true){
                    out.println("succses");
                    while (true){
                        String answer = in.readLine();  
                        if(answer.matches("(.*)selectAllPost")) connect.selectAllPost();
                        else if(answer.matches("(.*)insertPost")) connect.insertPost();
                        else if(answer.matches("(.*)deletePost")) connect.delPost();
                        else if(answer.matches("(.*)updatePost")) connect.updPost();
                        else if(answer.matches("(.*)searchPost")) connect.searchPost();
                        else if(answer.matches("(.*)selectCheckIn")) connect.selectCheckIn();
                        else if(answer.matches("(.*)insertCheckIn")) connect.insertCheckIn();
                        else if(answer.matches("(.*)deleteCheckIn")) connect.delCheckIn();
                        else if(answer.matches("(.*)updateCheckIn")) connect.updCheckIn();
                        else if(answer.matches("(.*)searchCheckIn")) connect.searchCheckIn();
                        else if(answer.matches("(.*)selectReserv")) connect.selectReserv();
                        else if(answer.matches("(.*)insertReserv")) connect.insertReserv();
                        else if(answer.matches("(.*)deleteReserv")) connect.delReserv();
                        else if(answer.matches("(.*)updateReserv")) connect.updReserv();
                        else if(answer.matches("(.*)searchReserv")) connect.searchReserv();
                        else if(answer.matches("(.*)selectApart")) connect.selectApart();
                        else if(answer.matches("(.*)insertApart")) connect.insertApart();
                        else if(answer.matches("(.*)updateApart")) connect.updApart();
                        else if(answer.matches("(.*)searchApart")) connect.searchApart();
                        else if(answer.matches("(.*)deleteApart")) connect.delApart();
                        else if(answer.matches("(.*)exit")) break;
                    }
                    connect.dbConnectionClose();
                    out.close();
                    in.close();
                    objectOut.close();
                    objectIn.close();
                }
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            } catch (InterruptedException | ClassNotFoundException | SQLException ex) {
                Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, InterruptedException {
        ServerSocket s = new ServerSocket(8060);
        System.out.println("Server started");
        try {
            while (true) {
                Socket socket = s.accept();
                try{
                    dbServer server = new dbServer(socket);
                    server.start();
                    server.join();
                }
                finally{
                    socket.close();
                }
            }
        }
        finally {
            s.close();
            System.out.println("Server closed");
        }
    }
}
